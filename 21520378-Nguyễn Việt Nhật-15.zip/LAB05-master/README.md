# IT012.M21.KHTN/LAB05

Viết chương trình Assembly thực hiện các yêu cầu sau:

- Nhập một mảng gồm N số tự nhiên (N do người dùng nhập vào)
- Sắp xếp mảng tăng dần bằng các phương pháp:
  * Bubble sort
  * Selection sort
  * Insertion sort


# Start at Mon, 5-30-2022
 
Họ và tên: **Nguyễn Việt Nhật**

MSSV: **21520378** - STT: **15**

Lớp: **KHTN2021**

GVHD: **Ths. Trương Văn Cương**

*Mô phỏng trên Mars 4.5*
